<?php

namespace Drupal\account\Entity\my_entity;

use Drupal\account\Entity\AccountBaseViewsData;

/**
 * Provides Views data for MyEntity entities.
 */
class MyEntityViewsData extends AccountBaseViewsData {

  /**
   * {@inheritdoc}
   */
  public function getViewsData() {
    return parent::getViewsData();
  }

}