<?php

namespace Drupal\account\Form\my_entity;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting MyEntity entities.
 *
 * @ingroup account
 */
class MyEntityDeleteForm extends ContentEntityDeleteForm {


}