<?php

namespace Drupal\account\my_entity;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for my_entity.
 */
class MyEntityTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.

}
